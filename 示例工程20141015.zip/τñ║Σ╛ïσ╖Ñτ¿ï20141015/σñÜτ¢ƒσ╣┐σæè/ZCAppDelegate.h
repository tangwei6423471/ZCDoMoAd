//
//  ZCAppDelegate.h
//  多盟广告
//
//  Created by zhangcheng on 14-8-23.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
